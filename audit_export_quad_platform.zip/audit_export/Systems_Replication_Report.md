# QUAD-PLATFORM MICROARCHITECTURAL SYSTEMS REPLICATION REPORT
## Empirical Systems Evaluation: macOS ARM64 (Apple M4) vs. Linux x86_64 vs. Windows 11 x86_64 (NVIDIA) vs. Windows 10/11 x86_64 (Intel Graphics)

**Document Classification:** Systems Replication Report  
**Date of Consolidation:** 2026-11-21  
**Repository Branch:** `main`  
**Evaluation Scope:** Empirical measurement and quad-platform consolidation across 4 distinct physical hardware/OS profiles (35 raw JSONL datasets, 190 experimental cells).  

---

## 1. EXECUTIVE SUMMARY & CONSOLIDATED METRICS

This report documents the physical execution, microarchitectural instrumentation, and statistical consolidation of the **PicoClaw vs. OpenClaw** benchmark suite across **four distinct physical hardware platforms**:
1. **Platform 1 (Reference Architecture):** Apple Silicon Mac Mini M4 (Darwin 26.6.2, ARM64, 10-core SoC [4 Performance + 6 Efficiency], 24 GB Unified LPDDR5X Memory at 120 GB/s on-die bandwidth, Metal 3, Apple SMC `powermetrics` telemetry).
2. **Platform 2:** Dell G15 5520 under Ubuntu 26.04 LTS (Kernel Linux 7.0.0-43-generic x86_64, Intel Core i5-12500H [16 logical threads], 30.5 GiB DDR5-4800, discrete NVIDIA GeForce RTX 3050 Laptop GPU 4 GB VRAM, Intel RAPL MSR + NVIDIA NVML + `perf_event_open`).
3. **Platform 3:** Dell G15 5520 under Microsoft Windows 11 64-bit (Build 26200 x86_64, Intel Core i5-12500H [16 logical threads], 31.7 GiB DDR5-4800, discrete NVIDIA GeForce RTX 3050 Laptop GPU 4 GB VRAM, Intel MSR RAPL + NVML DLL + Win32 PSAPI + WDDM).
4. **Platform 4:** MSI Z97 XPOWER AC under Microsoft Windows 10 Pro 64-bit (Build 19045 x86_64, Intel Core i7-4790K @ 4.00 GHz [4 cores / 8 threads], 15.88 GiB Shared DDR3-1600 System RAM, integrated Intel HD Graphics 4600 iGPU UMA, Win32 PSAPI process telemetry in unprivileged user-mode).

> **Methodological Note on Offload Regimes and Regime B Commensurability (Dell G15 Linux/Windows & Intel iGPU):**  
> Neural inference on the Dell G15 nodes (Linux and Windows 11) operated under a hybrid offload regime (`-ngl 16`, allocating approximately 3.0 GiB within the 4 GB GDDR6 VRAM ceiling and retaining remaining layers in host DDR5 memory), inducing continuous PCIe 4.0 host-to-GPU streaming (~5.2 GB/s). On the Intel HD Graphics 4600 node, inference executed over a shared DDR3 host memory aperture (UMA). Consequently, absolute warm-cache (Regime B) latency gains on the x86_64 nodes are constrained by PCIe/RAM bandwidth saturation and are not directly commensurable with the Apple M4 unified memory architecture.

> **Authorship and Execution Node Declaration:** Git author `drsgima` (author of the Windows testbed commits) operated the dedicated Windows physical testbed nodes.

### Key Empirical Findings (Workload W2 -- Standard 15-Tool Chain):
- **Client Middleware Dispatch Latency ($T_{\text{orch}}$):**
  * **macOS ARM64 (M4):** PicoClaw Go achieved a median latency of **5.53 ms** vs. OpenClaw Full at **24.55 ms** (**4.44x speedup**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Linux x86_64:** PicoClaw Go achieved a median latency of **6.68 ms** vs. OpenClaw Full at **35.53 ms** (**5.31x speedup**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Windows 11 NVIDIA:** PicoClaw Go achieved a median latency of **13.11 ms** vs. OpenClaw Full at **48.55 ms** (**3.70x speedup**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Windows Intel iGPU:** PicoClaw Go achieved a median latency of **14.03 ms** vs. OpenClaw Full at **68.89 ms** (**4.91x speedup**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
- **Resident Physical Memory Footprint (Peak RSS):**
  * **macOS ARM64 (M4):** PicoClaw Go stabilized at **5.09 MB** vs. OpenClaw Full at **37.71 MB** (**7.41x memory reduction**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Linux x86_64:** PicoClaw Go stabilized at **9.69 MB** vs. OpenClaw Full at **86.64 MB** (**8.94x memory reduction**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Windows 11 NVIDIA:** PicoClaw Go stabilized at **10.20 MB** vs. OpenClaw Full at **72.93 MB** (**7.15x memory reduction**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
  * **Windows Intel iGPU:** PicoClaw Go stabilized at **8.19 MB** vs. OpenClaw Full at **54.76 MB** (**6.69x memory reduction**; Cliff's $\delta = 1.00$, Mann-Whitney $p < 0.0001$).
- **Instruction Bloat and Hardware PMC / CPU Cycle Telemetry:**
  * **macOS ARM64 (Apple PMU):** OpenClaw Full executed **791.7M instructions**, compared to **62.3M** in PicoClaw (**12.71x ratio**).
  * **Linux x86_64 (`perf_event_open`):** OpenClaw Full executed **772.1M instructions**, compared to **32.4M** in PicoClaw (**23.87x ratio**).
  * **Windows 11 NVIDIA (`QueryProcessCycleTime`):** Hardware instruction counters are restricted in user-mode (`N/A*`); empirical CPU cycles confirm **528.1M cycles** in OpenClaw Full vs. **45.8M** in PicoClaw (**11.54x cycle ratio**).
  * **Windows Intel iGPU (`QueryProcessCycleTime`):** Hardware instruction counters are restricted in user-mode (`N/A*`); empirical CPU cycles confirm **1446.1M cycles** in OpenClaw Full vs. **87.8M** in PicoClaw (**16.47x cycle ratio**).

---

## 2. HARDWARE THROTTLING & IDLE POWER DECOMPOSITION

### 2.1. NVML Register Inspection and Thermal/Power Throttling Diagnostics (Linux and Windows)
Detailed inspection of raw JSONL telemetry records across all trials on Linux and Windows characterizes thermal and power-limit behavior:
- **Stationary Cumulative Counter on Linux (`cpu_pkg_throttle_events`):** Recorded values in `cpu_pkg_throttle_events` reflect monotonic sticky-bit accumulation from the Intel CPU package thermal status MSR (`IA32_PACKAGE_THERM_STATUS`) rather than progressive throughput degradation during benchmark trials.
- **Mobile TDP Power Cap on Windows (`gpu_sw_power_cap`):** Bitmask `0x8` (`SW_POWER_CAP`) events on Windows 11 NVIDIA reflect transient mobile GPU TDP enforcement (75 W board ceiling) during matrix-multiplication bursts in prompt prefill, rather than thermal throttling.
- **Absence of Hardware Thermal Throttling:** Across all discrete-GPU trials on Linux and Windows, the NVML thermal-throttle indicator (`gpu_thermal_throttle_active_end`) recorded **0 thermal throttling events**. GPU temperatures stayed within 50.0°C--74.0°C, below the 87.0°C threshold required to trigger `HW_THERMAL_SLOWDOWN` (`0x40`) or `SW_THERMAL_SLOWDOWN` (`0x20`).

### 2.2. Explicit Idle Power ($P_{\text{idle}}$) Telemetry and Duration Integration
Idle power baselines were empirically characterized during dedicated quiescence intervals prior to benchmark execution:
- **macOS ARM64 (Apple M4):** $P_{\text{idle}} = 1.20\text{ W}$ (Apple SMC SoC Package, quiescent range 1.00 W--1.46 W).
- **Linux x86_64 (Ubuntu 26.04):**
  * Session 1: $P_{\text{idle}} = 19.71\text{ W}$ (Intel CPU Package RAPL: 14.74 W, discrete NVIDIA GPU NVML: 4.98 W).
  * Session 2: $P_{\text{idle}} = 20.08\text{ W}$ (Intel CPU Package RAPL: 15.10 W, discrete NVIDIA GPU NVML: 4.98 W).
- **Windows 11 x86_64 (NVIDIA):**
  * Session 1: $P_{\text{idle}} = 24.13\text{ W}$ (Intel CPU Package RAPL MSR: 15.20 W, discrete NVIDIA GPU NVML: 8.93 W).
  * Session 2: $P_{\text{idle}} = 21.96\text{ W}$ (Intel CPU Package RAPL MSR: 15.20 W, discrete NVIDIA GPU NVML: 6.76 W).
- **Windows 10/11 x86_64 (Intel Graphics):**
  * Sessions 1 & 2: $P_{\text{idle}} = 28.50\text{ W}$ (Intel Core i7-4790K host package baseline). Dynamic host package energy is marked `N/A**` due to unprivileged user-mode execution without a kernel MSR RAPL driver.

> **Explanation of Apparent $P_{\text{idle}}$ Duration Scaling in Linux:**
> The telemetry harness computes net dynamic energy by subtracting $P_{\text{idle}} \times \text{trial\_wall\_s}$ from gross energy across the complete trial lifecycle (including subprocess initialization, loopback socket binding, and process teardown). In short-duration workloads (W1--W2), $\text{trial\_wall\_s} > T_{\text{task}}$ due to fixed subprocess overhead. Dividing $(E_{\text{total}} - E_{\text{net}})$ by $T_{\text{task}}$ yields an apparent variation from ~24.9 W (W1) to ~20.1 W (W4), which is a lifecycle duration-ratio artifact rather than sensor drift.

---

## 3. STATISTICAL SERIAL DEPENDENCE & DRIFT ANALYSIS

Following established systems benchmarking methodology (Kalibera & Jones 2013; Hoefler & Belli 2015; Maricq et al. 2018; Künsch 1989), serial dependence and temporal drift were evaluated across all experimental cells:

### 3.1. Autocorrelation ($r_1$), Effective Sample Size ($n_{\text{eff}}$), and Moving Block Bootstrap
- **Regime A (Cold Prefill):** Lag-1 serial autocorrelation across platforms spanned: macOS ARM64 $r_1 \in [-0.310, +0.433]$; Linux x86_64 $r_1 \in [-0.340, +0.778]$; Windows 11 NVIDIA $r_1 \in [-0.313, +0.219]$; Windows Intel iGPU $r_1 \in [-0.463, +0.193]$. White-noise 95% boundary at $n=30$ is $|r_1| < 2/\sqrt{30} \approx 0.365$.
- **Regime B (Warm Cache):** Serial autocorrelation emerged in a subset of warm-cache cells:
  * On macOS ARM64, lag-1 autocorrelation spanned $r_1 \in [-0.895, +0.434]$, with negative alternation attributed to harness dispatch cadence, loopback TCP socket drainage, and server thread wake-up scheduling.
  * On Windows 11 NVIDIA, lag-1 autocorrelation spanned $r_1 \in [-0.386, +0.450]$, reflecting memory page retention in the Windows Standby List.
  * For every cell exceeding $|r_1| > 2/\sqrt{n}$, the effective sample size $n_{\text{eff}} = \min(n, n(1 - r_1)/(1 + r_1))$ was computed and 95% confidence intervals were obtained via **Moving Block Bootstrap (MBB, block size $b=3$; Künsch 1989)** to preserve short-range serial correlation.
- **Interpretation of $n_{\text{eff}}$:** Mann-Whitney $U$, Cliff's $\delta$, and Vargha-Delaney $A_{12}$ statistics reflect $n=30$ measured trials per condition; $n_{\text{eff}}$ is reported exclusively as a diagnostic indicator of serial correlation health alongside MBB confidence intervals.

### 3.2. Linear Regression Drift Test with Holm-Bonferroni Family-Wise Error Control
Ordinary least-squares regression of task latency against repetition index ($1 \dots 30$) was evaluated across all experimental cells with Holm-Bonferroni FWER adjustment (Holm 1979):
- Across all **190 experimental cells**, **188/190 (98.9%) exhibited no statistically significant temporal drift** ($p_{\text{adj}} \ge 0.05$).
- In the small fraction of cells with statistically detectable slope (e.g., long-context W4 prefill), per-repetition slope magnitudes remained below $0.1\%$ of task duration.

---

## 4. CONSOLIDATED EMPIRICAL TABLES SUMMARY

### 4.1. Table 5: Tool-RAG Schema Pruning Analysis
- **Token Reduction:** Dynamic Tool-RAG pruning reduces active prompt tokens from 7,091 (static 54-tool catalog) to **917 tokens** (retrieved Top-5 schema), a **$-87.1\%$ token reduction**.
- **Regime A (Cold Prefill) Speedups (OpenClaw Tool-RAG vs. 54-Tool Full):** **7.28x** on macOS M4, **5.16x** on Linux x86_64, **4.64x** on Windows 11 NVIDIA, and **9.96x** on Windows Intel iGPU.
- **Baseline Normalization Transparency:** On macOS ARM64, speedups reference the internal unmitigated 54-tool baseline measured in the identical session (`tool_rag_mitigation_trials.jsonl`). On Linux x86_64, Windows 11 NVIDIA, and Windows Intel iGPU, pruned arms reference each node's primary unmitigated baseline (`raw_trials.jsonl` for Regime A; `warm_cache_trials.jsonl` for Regime B).

### 4.2. Table 4: KV-Cache Thrashing & Slot Isolation
- Cache eviction penalties quantified as the latency ratio of uncontrolled thrashing to block-isolated slot retention ($T_2/T_3$):
  * **macOS ARM64 (M4):** Minimal catalog penalty $= 6.85\text{x}$; Full catalog penalty $= 19.46\text{x}$.
  * **Linux x86_64:** Minimal catalog penalty $= 1.48\text{x}$; Full catalog penalty $= 2.63\text{x}$.
  * **Windows 11 NVIDIA:** Minimal catalog penalty $= 2.01\text{x}$; Full catalog penalty $= 2.30\text{x}$.
  * **Platform Scope:** Evaluated on the 3 primary nodes (macOS M4, Linux x86_64, Windows 11 NVIDIA); Windows Intel iGPU was scoped to W2 and W5 workloads.

### 4.3. Table 3: Cache Invariance Clarification
- Empirical measurements confirm that **cache invariance applies strictly to absolute orchestrator latency $T_{\text{orch}}$ (ms)** ($|\Delta T_{\text{orch}}| < 2.0\text{ ms}$, with a maximum observed difference of $1.95\text{ ms}$ for PicoClaw (Go) on Windows 11 NVIDIA).
- The relative overhead fraction $\Phi_{\text{orch}} = T_{\text{orch}} / T_{\text{task}}$ increases under warm cache because neural inference latency $T_{\text{neural}}$ drops substantially under KV prefix reuse.

### 4.4. Table 7: Multi-Platform Dual-Session Replication (TOST)
- Dual-session contrast analysis ($\Delta T_{\text{orch}} = T_{\text{orch}}(\text{Runtime}) - T_{\text{orch}}(\text{PicoClaw})$) across **102 platform/regime/workload pairs** using Two One-Sided Tests (`ttost_ind`, margin $\max(5.0\text{ ms}, 15\%\cdot|\bar{\Delta}_1|)$; Schuirmann 1987) yielded:
  * **Equivalence Proven ($p < 0.05$):** **53/102 (52.0%)**
  * **Replicated ($|\Delta| < 10\%$):** **29/102 (28.4%)**
  * **Divergence Detected ($|\Delta| \ge 10\%$ and $p \ge 0.05$):** **20/102 (19.6%)**
- Extreme W5 outliers (macOS ARM64 (M4) Regime B (Warm) W5 (PythonNative vs PicoClaw: +15360.46%); Linux x86_64 Regime A (Cold) W5 (PythonNative vs PicoClaw: +11936.37%)) occurred in `PythonNative` due to cross-session initialization variability during dynamic LangChain/CPython module resolution.

### 4.5. Table 8: Enterprise LangChain + SQLite Workload (W5)
- Table 8 consolidates W5 across **all 4 physical platforms** (macOS M4, Linux x86_64, Windows 11 NVIDIA, and Windows Intel iGPU) in both Cold and Warm regimes.
- **Quality Score Audit (`quality_score`):** LLM-as-a-Judge scoring (Zheng et al. 2023) was instrumented on `python_native` LangChain Core runs on macOS M4 (**1.0/5.0**, due to strict schema validation mismatch) and Windows Intel iGPU (**3.0/5.0**, partial query completion). Client agent runs (`picoclaw`, `openclaw_minimal`, `openclaw_full`, `bun_minimal`) and Linux/Windows NVIDIA W5 campaigns did not run the LLM-as-a-Judge wrapper and are explicitly marked `N/A†`.

---

## 5. FORMAL LITERATURE REFERENCES

1. **Kalibera, T. & Jones, R. (2013):** *Rigorous Benchmarking in Reasonable Time*, ACM ISMM '13, pp. 63--74. DOI: `10.1145/2464157.2464160`
2. **Hoefler, T. & Belli, R. (2015):** *Scientific Benchmarking of Parallel Computing Systems*, ACM/IEEE SC '15, Article 73, pp. 73:1--73:12. DOI: `10.1145/2807591.2807644`
3. **Maricq, A., Duplyakin, D., Jimenez, I., Maltzahn, C., Stutsman, R., & Ricci, R. (2018):** *Taming Performance Variability*, USENIX OSDI '18, pp. 409--425. ISBN: `978-1-939133-08-3`
4. **Künsch, H. R. (1989):** *The Jackknife and the Bootstrap for General Stationary Observations*, The Annals of Statistics, 17(3):1217--1241. DOI: `10.1214/aos/1176347265`
5. **Schuirmann, D. J. (1987):** *A Comparison of the Two One-Sided Tests Procedure and the Power Approach for Assessing the Equivalence of Average Bioavailability*, Journal of Pharmacokinetics and Biopharmaceutics, 15(6):657--680. DOI: `10.1007/BF01068419`
6. **Mann, H. B. & Whitney, D. R. (1947):** *On a Test of Whether One of Two Random Variables is Stochastically Larger than the Other*, The Annals of Mathematical Statistics, 18(1):50--60. DOI: `10.1214/aoms/1177730491`
7. **Kruskal, W. H. & Wallis, W. A. (1952):** *Use of Ranks in One-Criterion Variance Analysis*, Journal of the American Statistical Association, 47(260):583--621. DOI: `10.1080/01621459.1952.10483441`
8. **Holm, S. (1979):** *A Simple Sequentially Rejective Multiple Test Procedure*, Scandinavian Journal of Statistics, 6(2):65--70. DOI: `10.2307/4615733`
9. **Cliff, N. (1993):** *Dominance Statistics: Ordinal Analyses to Answer Ordinal Questions*, Psychological Bulletin, 114(3):494--509. DOI: `10.1037/0033-2909.114.3.494`
10. **Vargha, A. & Delaney, H. D. (2000):** *A Critique and Improvement of the "CL" Common Language Effect Size Statistics of McGraw and Wong*, Journal of Educational and Behavioral Statistics, 25(2):101--132. DOI: `10.3102/10769986025002101`
11. **Weaver, V. M., Terpstra, D., & Moore, S. (2013):** *Non-Determinism and Overcount on Modern Hardware Performance Counter Implementations*, IEEE ISPASS 2013, pp. 215--224. DOI: `10.1109/ISPASS.2013.6557172`
12. **Kwon, W. et al. (2023):** *Efficient Memory Management for Large Language Model Serving with PagedAttention*, ACM SOSP '23, pp. 611--626. DOI: `10.1145/3600006.3613165`
13. **Yao, S. et al. (2023):** *ReAct: Synergizing Reasoning and Acting in Language Models*, ICLR 2023 (`arXiv:2210.03629`).
14. **Zheng, L. et al. (2023):** *Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena*, NeurIPS 2023 (`arXiv:2306.05685`).
15. **Reddi, V. J. et al. (2020):** *MLPerf Inference Benchmark*, ACM/IEEE ISCA 2020, pp. 446--459. DOI: `10.1109/ISCA45697.2020.00045`
16. **You, J., Chung, J.-W., & Chowdhury, M. (2023):** *Zeus: Understanding and Optimizing GPU Energy Consumption of DNN Training*, USENIX NSDI '23, pp. 119--139. ISBN: `978-1-939133-33-5`
17. **Barroso, L. A. & Hölzle, U. (2007):** *The Case for Energy-Proportional Computing*, IEEE Computer, 40(12):33--37. DOI: `10.1109/MC.2007.443`
18. **Fahad, M., Shahid, A., Manumachu, R. R., & Lastovetsky, A. (2019):** *A Comparative Study of Methods for Measurement of Energy of Computing*, Energies, 12(11):2204. DOI: `10.3390/en12112204`
19. **Williams, S., Waterman, A., & Patterson, D. (2009):** *Roofline: An Insightful Visual Performance Model for Multicore Architectures*, Communications of the ACM, 52(4):65--76. DOI: `10.1145/1498765.1498785`
20. **Smith, A. M., Katz, D. S., Niemeyer, K. E., & FORCE11 Software Citation Working Group (2016):** *Software Citation Principles*, PeerJ Computer Science, 2:e86. DOI: `10.7717/peerj-cs.86`

---

## 6. CRYPTOGRAPHIC MANIFEST AUDIT & TRIAL INVENTORY

Every empirical `.jsonl` file validated on disk is listed below with its exact relative path, total record count, measured trial count, warmup count, workloads, and SHA-256 digest:

| Relative Path | Platform | Session Identifier | Role | Workloads | Total Lines | Measured Trials | Warmup Trials | SHA-256 Checksum |
| :--- | :--- | :--- | :--- | :--- | ---: | ---: | ---: | :--- |
| `results/publication_campaign/raw_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `raw` | W1, W2, W3, W4, W5 | 825 | 750 | 75 | `9f624bd429c810fbbaa2c952b18ea718b17d42b7b8667d6419c561ec7f60ed01` |
| `results/publication_campaign/warm_cache_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `warm` | W1, W2, W3, W4, W5 | 825 | 750 | 75 | `bd2854fd866a1d1b963ef7cfe8e659e6c68b59794c1cf6c3ac4f38952f79dea6` |
| `results/publication_campaign/kv_cache_thrashing_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `kv` | W2 | 90 | 90 | 0 | `48532324bcb7ad5c0d072c80571480e308dfdf48029312cded4677f47bbd3081` |
| `data/mcp_live_transport_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `mcp` | W2 | 135 | 135 | 0 | `03e8d3bd247e29c498e87a727daaa41d47e4d3b6005713d25a0a33301d3232c4` |
| `results/publication_campaign/tool_rag_mitigation_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `rag` | W1, W2, W3, W4 | 1056 | 960 | 96 | `3631f7843cef17e9a6c53fd2fc0970164c10ec090433d1f034e4d3238e35dc22` |
| `results/publication_campaign/prefill_ablation.jsonl` | macOS (M4) | `darwin_m4_session1` | `prefill` | 8 conditions | 528 | 480 | 48 | `ce1a12908ef22c0c40b1ff42c3a17a0914779234d9e81e003c7cf2d1b2ee9f5f` |
| `results/publication_campaign/uma_energy_bandwidth_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `uma` | W2, W3 | 120 | 120 | 0 | `960dbbe9c568134175a5c049a3e5f936bcebeb69c93777c4dc7037c6a58a31e3` |
| `data/external_framework_langchain_trials.jsonl` | macOS (M4) | `darwin_m4_session1` | `langchain` | W1, W2, W3, W4 | 144 | 120 | 24 | `2fe416fbf8b74ca4dcd18bfb7bb58f69044fa31b8c5fb60a9f3f3658ea458365` |
| `results/publication_campaign/inter_session_trials.jsonl` | macOS (M4) | `darwin_m4_session2` | `warm` | W1, W2, W3, W4, W5 | 825 | 750 | 75 | `ca99fe1748f8e4c171f4a180e258c183797aae3291f7e0d3e44433c77e106ba0` |
| `data/linux_x86_64_session1/raw/raw_trials.jsonl` | Linux x86_64 | `linux_x86_64_session1` | `raw` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `65f27603213370acfc317357c2c8a01f2abb664858c443b1ae27941d9d9d54a5` |
| `data/linux_x86_64_session1/raw/warm_cache_trials.jsonl` | Linux x86_64 | `linux_x86_64_session1` | `warm` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `c7388d9d64c9b765ff29e4c91d7e5406b02764cc7cac48d6c7a06d0fd0962d67` |
| `data/linux_x86_64_session1/raw/kv_cache_thrashing_trials.jsonl` | Linux x86_64 | `linux_x86_64_session1` | `kv` | W2 | 184 | 180 | 4 | `b5217cdfae6f7ef23ee994b2555e5050150da3ba6303fa250550d1534b6ec559` |
| `data/linux_x86_64_session1/raw/mcp_live_transport_trials.jsonl` | Linux x86_64 | `linux_x86_64_session1` | `mcp` | W2 | 297 | 270 | 27 | `e8ba4fcbc7403346fb946e524571fe6bf69722eee7d58a560eaceccd1dd7c5f8` |
| `data/linux_x86_64_session1/raw/tool_rag_mitigation_trials.jsonl` | Linux x86_64 | `linux_x86_64_session1` | `rag` | W1, W2, W3, W4, W5 | 660 | 600 | 60 | `ac3c0f22fba876213b9ebe3f6e49edaa5e0c71446827ad6a9139bddf14650b32` |
| `data/linux_x86_64_session2/raw/raw_trials.jsonl` | Linux x86_64 | `linux_x86_64_session2` | `raw` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `43df3c3249528937871d9728bb4437107696117be1ec3af8f171f457a810957b` |
| `data/linux_x86_64_session2/raw/warm_cache_trials.jsonl` | Linux x86_64 | `linux_x86_64_session2` | `warm` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `3767a65018317e9e3e93efb0b595e6bc64150b2a454cce7d7baba473f9d379da` |
| `data/linux_x86_64_session2/raw/kv_cache_thrashing_trials.jsonl` | Linux x86_64 | `linux_x86_64_session2` | `kv` | W2 | 184 | 180 | 4 | `c67bfcd561c8ef224a44221a37494c4886d3598eaff1a18f4788977fcf20a328` |
| `data/linux_x86_64_session2/raw/mcp_live_transport_trials.jsonl` | Linux x86_64 | `linux_x86_64_session2` | `mcp` | W2 | 297 | 270 | 27 | `907a8e21bc41eedc92f3fec78b2e9dc46fd2fd31e80a9e6073426570b5c655e9` |
| `data/linux_x86_64_session2/raw/tool_rag_mitigation_trials.jsonl` | Linux x86_64 | `linux_x86_64_session2` | `rag` | W1, W2, W3, W4, W5 | 660 | 600 | 60 | `65434ed3546fbb07f6fcabadeafe64762f4a774c7faab56ee7c3c552dd2d4598` |
| `data/windows_x86_64_session1/raw/raw_trials.jsonl` | Windows 11 | `windows_x86_64_session1` | `raw` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `264db96648f43c8301a936cd9e8a26895a8c79d284b5a78dd62021a1b4006cf9` |
| `data/windows_x86_64_session1/raw/warm_cache_trials.jsonl` | Windows 11 | `windows_x86_64_session1` | `warm` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `3091e23b550627a6b34b692f50566cf99f12ab3ac3fda820dbd2e66a953de019` |
| `data/windows_x86_64_session1/raw/kv_cache_thrashing_trials.jsonl` | Windows 11 | `windows_x86_64_session1` | `kv` | W2 | 184 | 180 | 4 | `5ab229460ef19505cd721cf795d7569337212a81fdd3652aa3275a4fb0f8de79` |
| `data/windows_x86_64_session1/raw/mcp_live_transport_trials.jsonl` | Windows 11 | `windows_x86_64_session1` | `mcp` | W2 | 297 | 270 | 27 | `9888d6edfabe937e2b0e85845314479b361013ba0fed24220ce58bf206abffab` |
| `data/windows_x86_64_session1/raw/tool_rag_mitigation_trials.jsonl` | Windows 11 | `windows_x86_64_session1` | `rag` | W1, W2, W3, W4, W5 | 660 | 600 | 60 | `449bc5204c6f1cd222002eeebd95a3ebbdc45915002a188eb4fa4a7a3b1848f9` |
| `data/windows_x86_64_session2/raw/raw_trials.jsonl` | Windows 11 | `windows_x86_64_session2` | `raw` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `f42f751681083f82787947c10244fecdd24c21ba6e123abd3752870d30568297` |
| `data/windows_x86_64_session2/raw/warm_cache_trials.jsonl` | Windows 11 | `windows_x86_64_session2` | `warm` | W1, W2, W3, W4, W5 | 990 | 900 | 90 | `d2df5802ed7c48e3064da8d5eabd27e9f494756bffdb4ad1429560c5286eb891` |
| `data/windows_x86_64_session2/raw/kv_cache_thrashing_trials.jsonl` | Windows 11 | `windows_x86_64_session2` | `kv` | W2 | 184 | 180 | 4 | `f4ac5017ceae16ff4c28b936b988d5f76f96f225e81de1d627970ccb5ce28786` |
| `data/windows_x86_64_session2/raw/mcp_live_transport_trials.jsonl` | Windows 11 | `windows_x86_64_session2` | `mcp` | W2 | 297 | 270 | 27 | `d9b1e3500af1b210405a7c87de1c6d442ccba36a41e355a99bba68ab16d12e36` |
| `data/windows_x86_64_session2/raw/tool_rag_mitigation_trials.jsonl` | Windows 11 | `windows_x86_64_session2` | `rag` | W1, W2, W3, W4, W5 | 660 | 600 | 60 | `ad45f15cb9bea1c483692b6e4dcf39062c709b4f2f2fad1267316692ac616e62` |
| `data/windows_intel_graphics_session1/raw/raw_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session1` | `raw` | W2, W5 | 330 | 300 | 30 | `e6993e9edeb9964f2109972da4444e6bca4d9952260961eebf1a3286d2a71d80` |
| `data/windows_intel_graphics_session1/raw/warm_cache_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session1` | `warm` | W2, W5 | 330 | 300 | 30 | `081809a8c7b44808fb0cfe41d4bdf7a08d77e68f8e16dfcf1f678ecfe5b4f7ab` |
| `data/windows_intel_graphics_session1/raw/tool_rag_mitigation_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session1` | `rag` | W2 | 132 | 120 | 12 | `b4501867f7a7642c18f31130f0f35e926e9aeb3e19d8a028ce32acf28afff669` |
| `data/windows_intel_graphics_session2/raw/raw_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session2` | `raw` | W2, W5 | 330 | 300 | 30 | `920d68b0197e3039021a1ca327b41807c2cd7b60ed1b606371f6d30e65854a33` |
| `data/windows_intel_graphics_session2/raw/warm_cache_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session2` | `warm` | W2, W5 | 330 | 300 | 30 | `d922a01b5dd42bd5ce8b4b9248bf6a4cb636a45384c025d9bffcb010f021e22c` |
| `data/windows_intel_graphics_session2/raw/tool_rag_mitigation_trials.jsonl` | Windows Intel iGPU | `windows_intel_graphics_session2` | `rag` | W2 | 132 | 120 | 12 | `34736fbad16b3fb5d499c14805a4e4700d21337ed7a57090bad8b98811a04157` |
| **TOTAL (35 files)** | **4 Platforms** | **All Sessions** | **All** | **W1--W5 + Ablations** | **18,616** | **16,995** | **1,621** | **Verified on Disk** |

---

## 7. EMPIRICAL SUMMARY & CONCLUDING OBSERVATIONS

The quad-platform measurement campaign shows that:
1. **Cross-Platform Persistence of Middleware Overhead:** Compiled Go (`PicoClaw`) exhibits lower client dispatch latency ($T_{\text{orch}}$) and smaller Peak RSS than Node.js V8 (`OpenClaw`) across all four hardware and operating system profiles.
2. **Quantified Replicability:** Moving Block Bootstrap confidence intervals and dual-session TOST tests quantify both replicated contrasts and session-level outliers (`PythonNative` on W5).
3. **Segregated Microarchitectural Grounding:** Retired hardware instruction ratios are evaluated within-ISA on ARM64 and x86_64 Linux, complemented by empirical Win32 CPU cycle ratios on both Windows platforms.
4. **Complete Artifact Traceability:** All raw JSONL datasets, analysis scripts, regenerated tables, figures, and SHA-256 manifests are synchronized in `main` for independent verification.
